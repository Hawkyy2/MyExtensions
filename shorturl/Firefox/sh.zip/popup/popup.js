
window.addEventListener('load', function(evt) {
	document.getElementById("urlclick").onclick = function() {myFunction()};
});

function myFunction() {
	    chrome.tabs.executeScript(null, { file: 'undead.js' }); 
	browser.runtime.sendMessage({ undo: "YOU CLICKED ME" });
}
