

browser.runtime.onMessage.addListener(notify);

function notify(message) {
console.log("the message came is::::"+message);
}
